package com.example.events_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
