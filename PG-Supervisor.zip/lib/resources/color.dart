import 'package:flutter/material.dart';

class CustomColor {
  static const Color dark_blue = Color(0xFF05008b);
  static const Color dark_cyan = Color(0xFF025ab5);
  static const Color sea_blue = Color(0xFF106db6);
  static const Color neon_green = Color(0xFF51ca98);
}
